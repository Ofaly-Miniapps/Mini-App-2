function myFunction(event) {
    event.preventDefault();

    alert("I am an alert box!");
  }